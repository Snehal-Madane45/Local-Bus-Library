﻿using System;

namespace Local_Bus_Pass_Generation_System
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
