﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LocalBussPassLibrary.Common
{
    public class AdminReport
    {
        public float totalPayment { get; set; }
        public int totalPass { get; set; }
    }
}
